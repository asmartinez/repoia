---
{
  "type": "Metadata Field",
  "title": "Nota de idioma",
  "description": "Campo descrito como «Nota de idioma». La intención se infiere de la etiqueta y el predicado local; confirmar el uso en registros antes de interpretaciones especializadas.",
  "resource": "https://github.com/ColmexBDCV/colmex_hyrax/blob/6f8bcb26568d03bc5b871bd620e7d9c13db64d17/app/models/concerns/hyrax/basic_metadata.rb#L64",
  "tags": [
    "metadata",
    "language_of_expression"
  ],
  "status": "stable",
  "generated": {
    "by": "process:hyrax-schema-extractor",
    "at": "2026-10-09T20:27:23.573601Z"
  },
  "verified": [
    {
      "by": "process:source-extraction",
      "at": "2026-10-09T20:27:23.573601Z"
    }
  ],
  "sources": [
    {
      "id": "definition",
      "resource": "https://github.com/ColmexBDCV/colmex_hyrax/blob/6f8bcb26568d03bc5b871bd620e7d9c13db64d17/app/models/concerns/hyrax/basic_metadata.rb#L64"
    },
    {
      "resource": "https://github.com/ColmexBDCV/colmex_hyrax/blob/6f8bcb26568d03bc5b871bd620e7d9c13db64d17/config/locales/colmex.es.yml#L894"
    }
  ],
  "field": {
    "name": "language_of_expression",
    "predicate": "::Vocab::RDAE.languagueOfExpresion",
    "multiple": true,
    "definitions": [
      {
        "path": "app/models/concerns/hyrax/basic_metadata.rb",
        "line": 64,
        "predicate": "::Vocab::RDAE.languagueOfExpresion",
        "multiple": true
      }
    ],
    "label": "Nota de idioma",
    "labelVariants": [
      "Nota de idioma"
    ],
    "searchable": true,
    "ambiguity": "",
    "meaning": "Campo descrito como «Nota de idioma». La intención se infiere de la etiqueta y el predicado local; confirmar el uso en registros antes de interpretaciones especializadas.",
    "labelSources": [
      {
        "path": "config/locales/colmex.es.yml",
        "line": 894
      }
    ]
  }
}
---
# Schema

- Nombre técnico: `language_of_expression`.
- Predicado declarado: `::Vocab::RDAE.languagueOfExpresion`.
- Cardinalidad explícita: True.
- Presente en el formulario avanzado observado: True. Esto confirma exposición, no integridad o calidad de todos sus valores.

Campo descrito como «Nota de idioma». La intención se infiere de la etiqueta y el predicado local; confirmar el uso en registros antes de interpretaciones especializadas.[^definition]

La verificación automática confirma la extracción del código, no la interpretación catalográfica ni su aprobación humana.

[^definition]: Definición en el código de Colmex Hyrax.
